# A Python Script to test Hello World extension
#
# 
#
import PyExt
print ("Demo for the Python 3.x Hello World...")
print ( PyExt.SayHello())