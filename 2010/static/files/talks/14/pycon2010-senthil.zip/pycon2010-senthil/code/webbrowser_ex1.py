import webbrowser
webbrowser.open('http://www.python.org')
webbrowser.open_new('http://uthcode.sarovar.org')
webbrowser.open_new_tab('http://www.python.org/dev')
