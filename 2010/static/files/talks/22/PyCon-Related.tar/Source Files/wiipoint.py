#-----------------------------------------------------------------------------
#   module name :   wiipoint.py
#   author      :   Asim Mittal (c) 2010
#   description :   This module defines IRPoint class, that contains routines pertinent
#                   to IR points and their abstraction

#   platform    :   Ubuntu 9.10 or higher (extra packages needed: pyqt4, pybluez)
#   
#   Disclamer
#   This file has been coded as part of a talk titled "Wii + Python = Intuitive Control"
#   delivered at the Python Conference (a.k.a PyCon), India 2010. The work here
#   purely for demonstartive and didactical purposes only and is meant to serve
#   as a guide to developing applications using the Nintendo Wii on Ubuntu using Python
#   The source code and associated documentation can be downloaded from my blog's
#   project page. The url for my blog is: http://baniyakiduniya.blogspot.com
#-----------------------------------------------------------------------------

import math

class IllegalPointAssignment:pass

countMaxIRPoints = 4

class IRPoint:
    
    def __init__(self,x=0,y=0,size=0):
        """ class constructor --> creates an object with three basic params: x,y,size """
        self.x = x
        self.y = y
        self.size = size
        
    def __str__(self):
        return "X:%s, Y:%s, Size:%s"%(self.x,self.y,self.size)
            
    def magnitude(self):
        """ using pythagoras theorem to get the distance of the point form an arbitary origin """
        return math.sqrt(math.pow(self.x,2)+math.pow(self.y,2))
    
    def calculateDisplacement(self,pointA,pointB):
        """ calculates the displacement from ptB to ptA and stores it in self """
        self.x = pointB.x - pointA.x
        self.y = pointB.y - pointA.y
        self.size = pointB.size - pointA.size 
    
    def getPointFromReportEntry(self, dctEntry):
        
        """ dctEntry is a dictionary entry of the type :
            {'pos': (x,y),'size': sizeValue}
            
            this routine simply extracts the position values for the IR point represented
            by the dictionary dctEntry
        """
        try:
            self.x = dctEntry['pos'][0]
            self.y = dctEntry['pos'][1]
            self.size = dctEntry['size']
        except:
            raise IllegalPointAssignment
        
    def nullify(self):
        """ make all members (x,y,size) zero """
        self.x = 0
        self.y = 0
        self.size = 0
        
    def scaleBy(self,scalingFactor):
        """ multiply all members of the IR point by scalingFactor """
        self.x *= scalingFactor
        self.y *= scalingFactor
        self.size *= scalingFactor