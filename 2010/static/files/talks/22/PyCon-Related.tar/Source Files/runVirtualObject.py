from PyQt4.QtGui import *
from PyQt4.QtCore import *
import sys,wiigrab,wiipoint,math

class VirtualObject(QWidget):

	def initWiimote(self):
		print 'Trying to connect to the wiimote, press 1 & 2 together...'
		try:
			self.oldCoords = [wiipoint.IRPoint(),wiipoint.IRPoint()]
			self.wiimote = wiigrab.WiimoteEventGrabber(self.handleWiimoteReport)
			self.wiimote.setReportType()
			self.wiimote.led = 15
			self.wiimote.start()
		except:
			QMessageBox.critical(self,'Connectivity Error','The application could not find any wiimotes, please ensure that the remote is discoverable and restart the application')
			self.close()
			sys.exit(0)

	def initWindow(self,xOrigin,yOrigin,width,height):
	
		self.setWindowTitle('Virtual Objects')
		self.setGeometry(xOrigin,yOrigin,width,height)
		self.setAttribute(Qt.WA_PaintOutsidePaintEvent)
		self.paint = QPainter()

	def initObject(self):
		
		self.sizeRed = [10,10]
		self.posRed = [30,30]
		self.boxColor = Qt.red
		self.angle = 0

	def __init__(self,parent=None):
		
		QWidget.__init__(self,parent)

		self.initWiimote()
		self.initWindow(100,100,500,500)
		self.initObject()

		self.timer = QTimer()

		self.connect(self,SIGNAL("resize"),self.stretchDot)
		self.connect(self,SIGNAL("move"),self.moveDot)
		self.connect(self.timer,SIGNAL("timeout()"),self.timeout)

		self.timer.start(20)

	def timeout(self):
		self.erase();self.draw()
		
	def paintEvent(self,event):
		self.draw()	

	def closeEvent(self,event):
		print 'Waiting for wiimote to disconnect...'
		try:
			self.wiimote.join()
			print 'Wiimote has disconnected successfully!'
		except:
			print 'Wiimote object could not be properly terminated!'

		print 'Closing app...'

	def moveDot(self,delX,delY):
		#self.erase()
		self.posRed[0] -= delX
		self.posRed[1] -= delY
		#self.draw()

	def stretchDot(self,delW,delH):
		#self.erase()
		self.sizeRed[0] -= delW
		self.sizeRed[1] -= delH
		#self.draw()

	def erase(self):
		self.paint.begin(self)
		self.paint.eraseRect(0,0,self.width(),self.height())
		self.paint.end()

	def draw(self):		
		self.paint.begin(self)
		self.paint.setBrush(self.boxColor)
		self.paint.rotate(self.angle)
		self.paint.drawRect(self.posRed[0],self.posRed[1],self.sizeRed[0],self.sizeRed[1])
		self.paint.end()
	
	def handleWiimoteReport(self,report,wiiref,tmp):
        
		rptIR,countVisible = wiigrab.getVisibleIRPoints(report)
		curIR1 = rptIR[0]
		curIR2 = rptIR[1]
		delX = 0
		delY = 0
		
		if countVisible <> 0 :
		
			if self.oldCoords[0].size <> 0 :
				delX = 	curIR1.x - self.oldCoords[0].x
				delY =  curIR1.y - self.oldCoords[0].y
				
			self.oldCoords[0] = curIR1
			
			if curIR2 <> None:
				self.emit(SIGNAL("resize"),delX,delY)
			else:
				self.emit(SIGNAL("move"),delX,delY)
		else:
			self.oldCoords[0].size = 0
		


if __name__ == '__main__':
	
	app = QApplication(sys.argv)
	frm = VirtualObject()
	frm.show()
	app.exec_()
