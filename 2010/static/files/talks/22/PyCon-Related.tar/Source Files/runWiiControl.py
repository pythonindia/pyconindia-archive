#-----------------------------------------------------------------------------
#   module name :   runWiiControl.py
#   author      :   Asim Mittal (c) 2010
#   description :   Demonstrates the integration of Xautomation with the Wiimote
#                   buttons
#   platform    :   Ubuntu 9.10 or higher (extra packages needed: pyqt4, pybluez)
#   
#   Disclamer
#   This file has been coded as part of a talk titled "Wii + Python = Intuitive Control"
#   delivered at the Python Conference (a.k.a PyCon), India 2010. The work here
#   purely for demonstartive and didactical purposes only and is meant to serve
#   as a guide to developing applications using the Nintendo Wii on Ubuntu using Python
#   The source code and associated documentation can be downloaded from my blog's
#   project page. The url for my blog is: http://baniyakiduniya.blogspot.com
#-----------------------------------------------------------------------------

import wiigrab,sys,time,os


#----------------------- Commands for various purposes ----------------------
cmdEnter = "xte \'key Return\'"
cmdLeft  = "xte \'key Left\'"
cmdRight = "xte \'key Right\'" 
cmdUp    = "xte \'key Up\'"
cmdDown  = "xte \'key Down\'"

cmdAltUp = "xte \'keyup Alt_R\'"

cmdZoomIn = "xte \'keydown Control_R\' \'keydown Alt_R\' \'str =\' \'keyup Alt_R\' \'keyup Control_R\'"
cmdZoomOut= "xte \'keydown Control_R\' \'keydown Alt_R\' \'str -\' \'keyup Alt_R\' \'keyup Control_R\'"
cmdMenu   = "xte \'keydown Alt_R\' \'key F1\' \'keyup Alt_R\'"
cmdClose  = "xte \'keydown Alt_R' \'key F4\' \'keyup Alt_R\'"
cmdMinim  = "xte \'keydown Alt_R' \'key F9\' \'keyup Alt_R\'"

cmdBack   = "xte \'keydown Alt_R' \'key Left\' \'keyup Alt_R\'" 
cmdForward= "xte \'keydown Alt_R' \'key Right\' \'keyup Alt_R\'" 
cmdTab    = "xte \'key Tab\'"
cmdSwitch = "xte \'keydown Alt_R\' \'key Tab\'"

cmdVLCSkip   = "xte \'keydown Control_R\' \'key Right\' \'keyup Control_R\'"
cmdVLCReplay = "xte \'keydown Control_R\' \'key Left\' \'keyup Control_R\'"
cmdVLCVolMore= "xte \'keydown Control_R\' \'key Up\' \'keyup Control_R\'"
cmdVLCVolLess= "xte \'keydown Control_R\' \'key Down\' \'keyup Control_R\'"
cmdVLCFullScr= "xte \'key F\'"
cmdVLCPlayPause  = "xte \'key Space\'"
cmdVLCPlaylist  = "xte \'keydown Control_R\' \'key L\' \'keyup Control_R\'"
cmdPptShow    = "xte \'key F5\'"

#-------------------- create a key map for each command ----------------------
keyMap = {
    
    
    (8,) :     cmdEnter,           #A 
    (2048,):   cmdUp,              #Up
    (1024,):   cmdDown,            #Down
    (512,):    cmdRight,           #Right
    (256,):    cmdLeft,            #Left
    (4096,):   cmdZoomIn,          #Plus
    (16,):     cmdZoomOut,           #Minus
    (2,):      cmdMinim,            #1
    (1,):      cmdClose,            #2
    (128,):    cmdMenu ,            #Home
    
    #now for the combos
    
    (4,2)  :  cmdPptShow, 
    (128,4):  cmdSwitch,               #B + Home
    (512,4):  cmdForward,           #B + Right
    (256,4):  cmdBack,              #B + left
    (2048,4): cmdVLCVolMore,        #B + Up
    (1024,4): cmdVLCVolLess,        #B + Down    
    (8,4):    cmdVLCPlayPause,      #A + B
    (4096,4): cmdVLCFullScr,         #B + plus
    (16,4):   cmdVLCPlaylist        #B + Minus
    
}
#---------------------------------------------------------------------------
flagAltDown = False

def buttonsHandler(report,wiiref,tempref):
        
    global keyMap,flagAltDown
    
    #capture the buttons that are being pressed, and resolve them
    buttonVal = report['buttons']
    lstResolved = tuple(wiigrab.resolveButtons(buttonVal))
    
    #if there is no button being pressed, and the alt key was down before this
    #then it means that the button has now been released. Hence alt key goes up
    if len(lstResolved) == 0 and flagAltDown == True:
        os.system(cmdAltUp)
        flagAltDown = False
    
    #pick out the key mapped to the following button value, if one exists
    if keyMap.has_key(lstResolved):
        cmd = keyMap[lstResolved] 
        #fire that command
        if cmd == cmdSwitch : flagAltDown = True
        os.system(cmd)
        
    
    
#------------------------------------ MAIN ------------------------------------------
if __name__ == "__main__":
	
	#------------------ Create Object, Connect and Configure -------------------
	try:
		print "Press the buttons 1 & 2 together..."
		wiiObj = wiigrab.WiimoteEventGrabber(buttonsHandler)
		wiiObj.setReportType()
		wiiObj.led = 15
	except:
		#print traceback.print_exc()
		print "Wii remote not found. Please check that the device is discoverable"
		sys.exit(0)

	#---- Start the Wiimote as a thread with reports fed to assigned callback----
	wiiObj.start()
	
	#----------------- Run the Main loop so that the app doesn't die ------------
	try:
		print 'Start of App'
           	print 'Controls'
           	print '------------' 
        	print 'Button A: Enter'
        	print 'Arrows: Arrow keys'
        	print 'Home: Application Menu'
        	print 'Plus: Zoom In'
        	print 'Minus: Zoom Out'
        	print 'Button 1: Minimize'
        	print 'Button 2: Close currently selected App'
        	print ''
        	print 'Button B + Button 1: View Slideshow'
        	print 'Button B + Home: Application Switcher'
        	print 'Button B + Right: Forward'
        	print 'Button B + Left: Backward'
        	print 'Button B + Up: VLC Volume Up'
        	print 'Button B + Dn: VLC Volume Down'
        	print 'Button B + A: VLC Play or Pause'
        	print 'Button B + Plus: VLC Full Screen toggle'
        
        
		while True: time.sleep(1)
	except:
		#very important call to join here, waits till the wiimote connection is closed and the 
		#wiimote is restored to its initial state
		wiiObj.join()
		print 'End of App'
	
