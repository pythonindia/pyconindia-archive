#-----------------------------------------------------------------------------
#   module name :   runPaintFire.py
#   author      :   Asim Mittal (c) 2010
#   description :   Imitation of the Paddle war / Air hockey game. Allows smooth
#                   and simultaneous control by two players
#   platform    :   Ubuntu 9.10 or higher (extra packages needed: pyqt4, pybluez)
#   
#   Disclamer
#   This file has been coded as part of a talk titled "Wii + Python = Intuitive Control"
#   delivered at the Python Conference (a.k.a PyCon), India 2010. The work here
#   purely for demonstartive and didactical purposes only and is meant to serve
#   as a guide to developing applications using the Nintendo Wii on Ubuntu using Python
#   The source code and associated documentation can be downloaded from my blog's
#   project page. The url for my blog is: http://baniyakiduniya.blogspot.com
#-----------------------------------------------------------------------------

from PyQt4.QtGui import *
from PyQt4.QtCore import *

import sys,wiigrab,wiipoint,math

class PaddleWar(QWidget):
    #---------------------------------------------------------------------------
    def initWiimote(self):
        """ initialize the wii remote here """
        try:
            print 'Press buttons 1 & 2 together...'
            self.oldCoordsIR = [wiipoint.IRPoint(),wiipoint.IRPoint()]                       #this member tracks the reference coords of the IR points
            self.wiimote = wiigrab.WiimoteEventGrabber(self.handleWiimoteReport,0.05,self)   #create the wiimote object and set the callback
            self.wiimote.setReportType()                                                     #set the report type to default (send all reports)
            self.wiimote.led = 15                                                            #let all the wiimote LEDs be on
            self.wiimote.start()                                                             #start the wiimote object thread
            
        except:
            #the wiimote could not be found, or that port is blocked/closed
            QMessageBox.critical(self,'Connectivity Error','The application could not find any Wiimotes. Please ensure your device is discoverable and restart the application')
            #self.close()
            #sys.exit(0)
    #---------------------------------------------------------------------------
    def closeEvent(self,event):
        """ event is called when the application closes down """
        print 'Waiting for Wiimote to disconnect...'
        try:
            #this routine ensures that the pipe between the app and the wiimote is
            #properly disconnected
            self.wiimote.join()
            print 'Wiimote disconnected!'
        except:
            print 'Wiimote object could not be located!'
            pass
            
        print 'Closing App...'
    #---------------------------------------------------------------------------
    def initWindow(self,xOrigin,yOrigin,width,height):
        """ initialize the main window and create the painter object """
        self.setGeometry(xOrigin,yOrigin,xOrigin+width,yOrigin+height)          #set the window geometry
        self.setWindowTitle('Paddle War')                                       #set the window title
        self.setAttribute(Qt.WA_PaintOutsidePaintEvent,True)                    #this attribute is very impt. allows us to paint without using paintEvent
        self.paint = QPainter()                                                 #create the painter object
    #---------------------------------------------------------------------------
    def initGameObjects(self):
        """ initialize the various parameters needed for the gameplay """
        self.sizeDot = (10,100)                                                 #the size of the red/blue dots
        self.sizeBox = 20                                                       #size of the object box
        self.posRed = [50,(self.height()/2 - self.sizeDot[1]/2)]                #this is the starting position of the red dot
        self.posBlue= [self.width()-50, (self.height()/2 - self.sizeDot[1]/2)]  #this is the starting position of the blue dot
        self.posBox = [self.width()/2, self.height()/2]                         #this is the starting position of the object box
        
        speed = 10                                                               #the speed at which the object box moves (in pixels)
        self.boxSpeedX = speed                                                  #set uniform speed along both x and y directions
        self.boxSpeedY = speed
        self.boxColor = Qt.darkMagenta                                          #set the color of the object box
        
        self.scoreRed = 0
        self.scoreBlue = 0
        
    #---------------------------------------------------------------------------
    def __init__(self,xOrigin,yOrigin,width,height,parent=None):
        """ Class constructor - this is where the app begins """
        QWidget.__init__(self,parent)
        
        self.initWiimote()
        self.initWindow(xOrigin,yOrigin,width,height)
        self.initGameObjects()
    
        #this is the application timer, that is called every 40 milliseconds. The game engine runs through this timer
        self.timer = QTimer()
        self.prepTimer = QTimer()   #the prep timer gives the players time to make adjustments
        self.startFlag = False
        
        #a few event bindings
        self.connect(self.timer,SIGNAL("timeout()"),self.timeOut)
        self.connect(self,SIGNAL("draw"),self.draw)         #this redraws the red/blue squares and the line between them
        self.connect(self,SIGNAL("moveRed"),self.moveRed)   #this repositions the coords of the red dot
        self.connect(self,SIGNAL("moveBlue"),self.moveBlue) #this repositions the coords of the blue dot
        
        #start the game by starting the prep package
        self.timer.start(40)
        self.prepTimer.singleShot(6000,self.startGame)
    #---------------------------------------------------------------------------
    def startGame(self): 
        """ this routine sets the start game flag indicating that the game is about to begin """
        self.startFlag = True
    #---------------------------------------------------------------------------
    def timeOut(self):
        """ this is called by the application timer. It is the game's core logic. There are three major 
            tasks to take care of when designing this routine. Animation of the objects (erasing the screen and 
            repainting it), collision detection of the ball with boundaries of the window, and finally collision
            detection of the ball with paddles.
        """
        if self.startFlag == True:
            
            self.eraseBox(self.posBox[0],self.posBox[1])        #start by erasing the object box off the screen
            offset = 5                                         #this offset is used to create an invisible boundary near the edges of the window
            
            #the scoring is done by touching the opponents boundary, so every collision against the
            #right or left edge of the window leads to a score by either player.
            
            if (self.posBox[0] >= (self.width() - offset)): self.boxSpeedX *=-1;self.scoreRed += 1  #red scores - ball reached right edge
            if (self.posBox[0] <= (offset)): self.boxSpeedX *= -1; self.scoreBlue +=1               #blue scores - ball reached left edge
            
            #the top and bottom edges of the window only cause the object to bounce about - so that is how it is done
            if (self.posBox[1] >= (self.height()- offset)) or (self.posBox[1] <= (offset)): self.boxSpeedY *= -1
            
            #now collision detection against the paddles is very important. The red paddle is on the left and the blue
            #paddle is on the right side of the window. Therefore, the right edge of the red and the left edge of the 
            #blue will be the two paddle faces, or contact areas. so getting the edges of each paddle face is the first step
            
            height = self.sizeDot[1]                #height and width of each paddle
            width = self.sizeDot[0]
            
            #now we get the x coords of the Red paddle's face. Since the paddles are vertically aligned the 
            #x coords remain same along the paddle face. the paddle moves only along the Y coords - and that means
            #there is a range of values it can take along the Y axis. this range is nothing but the points along
            #its height
            xEdgeRed = self.posRed[0] + width
            validYRangeRed = range(self.posRed[1],self.posRed[1]+height)
            
            #similarly we get the x coords for the blue paddle's face and its corresponding range of values
            #along the Y axis
            xEdgeBlue = self.posBlue[0]
            validYRangeBlue= range(self.posBlue[1],self.posBlue[1]+height)
            
            #now to detect a collision, all we do is simply check if any of the points lying on the object (ball)
            #coincide with the paddle faces (red/blue)
            collision = False
            
            for x in range(self.posBox[0],self.posBox[0]+self.sizeBox):                 #scan through all the x coords for the object box
                for y in range(self.posBox[1],self.posBox[1]+self.sizeBox):             #scan through all the y coords for the object box
                    
                    if (x == xEdgeRed) and (y in validYRangeRed): self.boxSpeedX *=-1;collision = True;break    #collision with red paddle face
                    if (x == xEdgeBlue) and (y in validYRangeBlue): self.boxSpeedX *=-1;collisoin = True;break  #collision with blue paddle face
                
                #this if clause prevents further computations to be made in case the collision was detected    
                if collision == True: break
            
            #now all the math is done, its time to move the object box (ball) to its new location
            self.posBox[0] += self.boxSpeedX
            self.posBox[1] += self.boxSpeedY
            
            #all this while the screen was cleared, now repaint the screen with the same objects
            #only with different positions - thereby creating the "animation"
            self.draw()
    #---------------------------------------------------------------------------
    def moveRed(self,delY):
        """ alter the position of the red square """
        newYPos = self.posRed[1] - delY 
        
        if newYPos < self.height() and newYPos > 0:     #check if the movement puts the paddle outside window boundary
            self.posRed[1] -= delY                      #if not, then move the paddle, else do nothing (keeps the paddle locked)
    #---------------------------------------------------------------------------    
    def moveBlue(self,delY):
        """ alter the position of the blue square """   
        newYPos = self.posBlue[1] - delY                
        
        if newYPos < self.height() and newYPos > 0:     #check if the movement puts the paddle outside window boundary
            self.posBlue[1] -= delY                     #if not,only then move the paddle, else do nothing
    #---------------------------------------------------------------------------        
    def eraseDrawing(self):
        """ Erase the drawing. The form is repainted and the graphics are wiped clean. 
            This is important as it creates the illusion of "animation" or "movement"
        """
        self.paint.begin(self)
        self.paint.eraseRect(0,0,self.width(),self.height())
        self.paint.end()
    #---------------------------------------------------------------------------
    def drawBox(self,x,y):
        """ this routine draws the object box (ball/puck) on the screen based on x,y coords """
        self.paint.begin(self)
        self.paint.setBrush(self.boxColor)
        self.paint.drawRect(x,y,self.sizeBox,self.sizeBox)
        self.paint.end()
    #---------------------------------------------------------------------------
    def eraseBox(self,x,y):
        """ erases the object box (ball/puck) from the last known location """
        offset = 1
        self.paint.begin(self)
        self.paint.eraseRect(x,y,self.sizeBox+offset,self.sizeBox+offset)
        self.paint.end()
    #---------------------------------------------------------------------------
    def drawRedDot(self,x,y):
        """ draws the red paddle at the specified x,y coords """
        self.paint.begin(self)
        self.paint.setBrush(Qt.red)
        self.paint.drawRect(x,y,self.sizeDot[0],self.sizeDot[1])
        self.paint.end()
    #---------------------------------------------------------------------------
    def drawBlueDot(self,x,y):
        """ draws the blue paddle at the specified x,y coords """
        self.paint.begin(self)
        self.paint.setBrush(Qt.blue)
        self.paint.drawRect(x,y,self.sizeDot[0],self.sizeDot[1])
        self.paint.end()
    #---------------------------------------------------------------------------
    def draw(self):
        """ draws all the game objects on the screen - paddles and object box and score """
        self.eraseDrawing()
        self.drawRedDot(self.posRed[0],self.posRed[1])
        self.drawBlueDot(self.posBlue[0],self.posBlue[1])
        self.drawBox(self.posBox[0],self.posBox[1])
        self.setWindowTitle("RED:%s\tBLUE:%s"%(self.scoreRed,self.scoreBlue))
    
    #---------------------------------------------------------------------------
    def keyPressEvent(self,event):
        """ allows the keyboard events to control paddles. Blue (up/down) Red (W/S) keys"""
        increment = 10
        delYRed = 0; delYBlue = 0
        
        #check for movement on the keys for blue paddle
        if      event.key() == Qt.Key_Up: delYBlue -= increment
        elif    event.key() == Qt.Key_Down: delYBlue += increment
        
        #check for movement on the keys for red paddle
        if    event.key() == Qt.Key_W: delYRed -= increment
        elif    event.key() == Qt.Key_S: delYRed += increment
        
        self.emit(SIGNAL("moveRed"),-delYRed)
        self.emit(SIGNAL("moveBlue"),-delYBlue)
    
    #---------------------------------------------------------------------------
    def paintEvent(self,event):
        """ called initially to paint the screen """
        self.draw()
    
    #---------------------------------------------------------------------------
    def handleWiimoteReport(self,report,wiiref,tmp):
        """ handles the events from the wii remote """
        
        rptIR,countVisible = wiigrab.getVisibleIRPoints(report)
        signals = [SIGNAL("moveBlue"),SIGNAL("moveRed")]
        scale = 2
        
        #if the maximum number of dots visible are 2, do the following
        if (countVisible > 0) and (countVisible < 3):
            
            #for each visible dot, perform the following operations
            for i in range(0,countVisible):
                
                #if the dot has some coordinate info
                if rptIR[i] <> None:
                    oldCoord = self.oldCoordsIR[i]              #save the old coordinate reference for this point
                    curCoord = rptIR[i]                         #save the current coordinate for this point
                
                    if oldCoord.size <> 0:                      #if this dot is not moving from rest position
                        delX = curCoord.x - oldCoord.x          #then compute displacement along the x and y directions
                        delY = curCoord.y - oldCoord.y          #displacement = current coords - old coords
                        
                        self.emit(signals[i],delY*scale) #tell the associated dot to move/displace by the same amount
                        #scaling is used so that a small movement of the IR point can effectively lead to a larger movement on screen
                
                    self.oldCoordsIR[i] = curCoord              #save the current coords as the reference for the next comparison
        
        elif countVisible == 0:
            #cannot see anymore IR points, rest the dots
            self.oldCoordsIR[0].size = 0
            self.oldCoordsIR[1].size = 0
            
#---------------------------------------------------------------------------
if __name__ == '__main__':
    
    app = QApplication(sys.argv)
    frm = PaddleWar(100,100,800,300)
    frm.show()
    app.exec_()