from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys,wiipoint,wiigrab,os,math
import xauto

class MouseMover(QWidget):
	#-------------------------------------------------------------------
	def initWiimote(self,handler):
		""" Initialize the wiimote and set up the event grabber """

		print 'Trying to connect to Wiimote. Press 1 & 2 together...'

		self.oldIRCoords = [wiipoint.IRPoint(),wiipoint.IRPoint()]
		self.gestureOn = False
		self.capture = []

		try:
			self.oldCoords = [wiipoint.IRPoint(),wiipoint.IRPoint()]
			self.wiimote = wiigrab.WiimoteEventGrabber(handler)
			self.wiimote.setReportType()
			self.wiimote.led = 15
			self.wiimote.start()
		except:
			print "Error connecting to the wiimote. Ensure that it is discoverable and restart the app"
			self.close()
			sys.exit(0)

	#--------------------------------------------------------------------
	def __init__(self):
		QWidget.__init__(self,None)
		self.initWiimote(self.handler)
		self.trayIcon = QSystemTrayIcon(QIcon(os.getcwd()+os.sep+"trayicon.png"),self)
		self.trayIcon.show()
		self.hide()

		self.connect(self.trayIcon,SIGNAL("activated(QSystemTrayIcon::ActivationReason)"),self.closeForm)
		self.connect(self,SIGNAL("moveCursor"),self.moveCursor)
		print QCursor.pos()

	#--------------------------------------------------------------------
	def moveCursor(self,x,y):
		curPos = QCursor.pos().x(),QCursor.pos().y()
		newPos = curPos[0]-x,curPos[1]-y
		QCursor.setPos(newPos[0],newPos[1])
 
	#--------------------------------------------------------------------
	def closeForm(self,reason):
		if reason == QSystemTrayIcon.Trigger: 
			sys.exit(0)
			
	#--------------------------------------------------------------------
	def closeEvent(self,event):
		try:
			self.wiimote.join()
			print 'Wiimote disconnected'
		except:
			print 'Wiimote object couldnt be found!'
		
	#-------------------------------------------------------------------------------------------------
	def handler(self,report,wiiref,tmp):
	
		rptIR,countVisible = wiigrab.getVisibleIRPoints(report)
		point = wiipoint.IRPoint()
		multiplier = 2

		if countVisible == 0:
			self.oldIRCoords[0].nullify()
			

		else:
			point.calculateDisplacement(self.oldIRCoords[0],rptIR[0])
			point.scaleBy(multiplier)
			if self.oldIRCoords[0].size <> 0:self.emit(SIGNAL("moveCursor"),point.x,point.y)
			self.oldIRCoords[0] = rptIR[0]

			if countVisible == 2:
				xauto.mouseDown(1)

			elif countVisible == 1:
				xauto.mouseUp(1)
			
			
		
	
#-------------------------------------------------------------------------------------------------
if __name__ == '__main__':
	
	app = QApplication(sys.argv)
	frm = MouseMover()
	app.exec_()



