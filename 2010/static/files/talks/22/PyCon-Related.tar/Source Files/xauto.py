import os
#------------------------- Xautomation Commands ----------------------------

buttonLeft  = 1
buttonRight = 2 
isMouseDown = False
zoomCount = 0
oldSize = 0
oldDist = 0
isSwitcherOn = False

cmdMouseMove = "xte \'mousemove %s %s\'"
cmdMouseDown = "xte \'mousedown %s\'"
cmdMouseUp   = "xte \'mouseup %s\'"
cmdZoomIn = "xte \'keydown Control_L\' \'keydown Alt_L\' \'str ====\' \'keyup Control_L\' \'keyup Alt_L\'"
cmdZoomOut = "xte \'keydown Control_L\' \'keydown Alt_L\' \'str ----\' \'keyup Control_L\' \'keyup Alt_L\'"
cmdControlOn = "xte \'keydown Control_L\' \'keydown Alt_L\'" 
cmdControlOff = "xte  \'keyup Control_L\' \'keyup Alt_L\'"

#------------------------------------------------------------------------
def moveCursor(x,y):
    toSend = (cmdMouseMove%(int(x),int(y)))
    os.system(toSend)
    
def mouseDown(button):
    global isMouseDown
    if isMouseDown == False:
        toSend = (cmdMouseDown%(int(button)))
        os.system(toSend)
        isMouseDown = True
		

def mouseUp(button):
    global isMouseDown
    if isMouseDown == True:
        toSend = (cmdMouseUp%(int(button)))
        os.system(toSend)
        isMouseDown = False
        
        

#-----------------------------------------------------------------------        
def zoomIn():
    global zoomCount
    os.system(cmdZoomIn)
    zoomCount +=1

def zoomOut():
    global zoomCount
    while zoomCount <> 0:
        os.system(cmdZoomOut)
        zoomCount -= 1

