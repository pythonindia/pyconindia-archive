#-----------------------------------------------------------------------------
#   module name :   simpleButtons.py
#   author      :   Asim Mittal (c) 2010
#   description :   Demonstrates the use of buttons for the wii
#   platform    :   Ubuntu 9.10 or higher (extra packages needed: pyqt4, pybluez)
#   
#   Disclamer
#   This file has been coded as part of a talk titled "Wii + Python = Intuitive Control"
#   delivered at the Python Conference (a.k.a PyCon), India 2010. The work here
#   purely for demonstartive and didactical purposes only and is meant to serve
#   as a guide to developing applications using the Nintendo Wii on Ubuntu using Python
#   The source code and associated documentation can be downloaded from my blog's
#   project page. The url for my blog is: http://baniyakiduniya.blogspot.com
#-----------------------------------------------------------------------------

import wiigrab, sys, time, traceback


def eventHandlerButtons(report,wiiObj,tempRef):

	#get the button value (sum of key presses) from the report
	buttonValue = report['buttons']

	#resolve this combined value using the wiigrab's resolver routine
	lstResolvedValues = wiigrab.resolveButtons(buttonValue)

	if len(lstResolvedValues) > 2: wiiObj.rumble = 1
	else:	wiiObj.rumble = 0							
	
	#get the nomenclature for every button
	lstNames = []
	for eachButtonVal in lstResolvedValues: lstNames.append(wiigrab.getNameOfButton(eachButtonVal))

	#print the names
	if lstNames <> []: print lstNames,lstResolvedValues

#------------------------------------ MAIN ------------------------------------------
if __name__ == "__main__":
	
	#------------------ Create Object, Connect and Configure -------------------
	try:
		print "Press the buttons 1 & 2 together..."
		wiiObj = wiigrab.WiimoteEventGrabber(eventHandlerButtons)
		wiiObj.setReportType()
		wiiObj.led = 15
	except:
		#print traceback.print_exc()
		print "Wii remote not found. Please check that the device is discoverable"
		sys.exit(0)

	#---- Start the Wiimote as a thread with reports fed to assigned callback----
	wiiObj.start()
	
	#----------------- Run the Main loop so that the app doesn't die ------------
	try:
		print 'Start of App'
		while True: time.sleep(1)
	except:
		#very important call to join here, waits till the wiimote connection is closed and the 
		#wiimote is restored to its initial state
		wiiObj.join()
		print 'End of App'
	
