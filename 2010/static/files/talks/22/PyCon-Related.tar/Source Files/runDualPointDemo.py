#-----------------------------------------------------------------------------
#   module name :   runDualPointDemo.py
#   author      :   Asim Mittal (c) 2010
#   description :   The IR Sandbox is used to demonstrate how two points can be individually
#                   tracked in space. The demo uses the concept of "iterative displacement", similar
#                   to the mouse touch pad that is used so commonly. The mouse always moves from its
#                   current position and you can span the entire screen using repetitive or iterative
#                   strokes
#                       
#   platform    :   Ubuntu 9.10 or higher (extra packages needed: pyqt4, pybluez)
#   
#   Disclamer
#   This file has been coded as part of a talk titled "Wii + Python = Intuitive Control"
#   delivered at the Python Conference (a.k.a PyCon), India 2010. The work here
#   purely for demonstartive and didactical purposes only and is meant to serve
#   as a guide to developing applications using the Nintendo Wii on Ubuntu using Python
#   The source code and associated documentation can be downloaded from my blog's
#   project page. The url for my blog is: http://baniyakiduniya.blogspot.com
#-----------------------------------------------------------------------------


from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys,wiipoint,wiigrab

class IRTracking(QWidget):
	#---------------------------------------------------------------------------------------------------------
	def initWiimote(self,handler):
		""" Initialize the wiimote and set up the event grabber """

		print 'Trying to connect to Wiimote...'
		try:
			self.oldCoords = [wiipoint.IRPoint(),wiipoint.IRPoint()]
			self.wiimote = wiigrab.WiimoteEventGrabber(handler,objTemp=self)
			self.wiimote.setReportType()
			self.wiimote.led = 15
			self.wiimote.start()
		except:
			print "Error connecting to the wiimote. Ensure that it is discoverable and restart the app"
			self.close()
			sys.exit(0)
	#---------------------------------------------------------------------------------------------------------
	def initWindow(self):
		""" setup the main window and its attributes """

		self.setGeometry(100,100,500,500)
		self.setWindowTitle('IR Tracking')
		self.paint = QPainter()
		self.setAttribute(Qt.WA_PaintOutsidePaintEvent)
	#---------------------------------------------------------------------------------------------------------
	def initObjects(self):
		""" setup the characteristics of two dots on the main window """
		self.sizeDot = 10
		self.posRed = [10,10]
		self.posBlue = [10,self.width()-10]
	#---------------------------------------------------------------------------------------------------------	
	def __init__(self,handler):
		""" class constructor """
		QWidget.__init__(self,None)						#base class constructor called
		self.initWiimote(handler)						#setup the wiimote - assign a handler for processing reports
		self.initWindow()								#init the window
		self.initObjects()								#setup the two dots
			
		self.connect(self,SIGNAL("moveDot"),self.move)	#assign an event binding for the moving either dot
	#---------------------------------------------------------------------------------------------------------
	def paintEvent(self,event): self.draw()
	#---------------------------------------------------------------------------------------------------------
	def erase(self):
		""" erases the two dots from their current positions """
		self.paint.begin(self)
		self.paint.eraseRect(self.posRed[0],self.posRed[1],self.sizeDot+1,self.sizeDot+1)
		self.paint.eraseRect(self.posBlue[0],self.posBlue[1],self.sizeDot+1,self.sizeDot+1)
		self.paint.end()
	#---------------------------------------------------------------------------------------------------------
	def draw(self):
		""" draw the two dots at their current positions in red and blue colors """
		self.paint.begin(self)
		self.paint.setBrush(Qt.red)
		self.paint.drawRect(self.posRed[0],self.posRed[1],self.sizeDot,self.sizeDot)
		self.paint.setBrush(Qt.blue)
		self.paint.drawRect(self.posBlue[0],self.posBlue[1],self.sizeDot,self.sizeDot)
		self.paint.end()
	#---------------------------------------------------------------------------------------------------------
	def move(self,dot,x,y):
		""" displace the specified dot by x and y  """
		self.erase()													#erase the two dots								
		if	dot == 0:	
			newPosX = self.posRed[0] - x
			newPosY = self.posRed[1] - y
			if (newPosX in range(0,self.width())):
				self.posRed[0] -= x; 
			if (newPosY in range(0,self.height())):
				self.posRed[1] -= y	

		elif	dot == 1:	
			newPosX = self.posBlue[0] - x
			newPosY = self.posBlue[1] - y
			if (newPosX in range(0,self.width())):
				self.posBlue[0] -= x; 
			if (newPosY in range(0,self.height())):
				self.posBlue[1] -= y	

		self.draw()														#now repaint the dots at their new positions

#----------------------------------------------------------------------------
def handleReportDualPointTracking(report,deviceRef,frmRef):
    
    """ this is the callback routine that is used for the dual point tracking demo 
        the principle of iterative displacement is used to move the dots about their 
        resting positions.
        
        The routine simply computes the displacement of the IR Points between successive
        calls. This displacement is refactored and the respective dot is displaced by a similar
        amount
    """
    
    #this gets the data for the points that are visible
    rptIR,countVisible = wiigrab.getVisibleIRPoints(report)
    point = wiipoint.IRPoint()
    
    multiplier = 1
    
    #this if clause is executed when there are no points visible
    if countVisible == 0:
        frmRef.oldCoords[0].nullify()
        frmRef.oldCoords[1].nullify()
    
    #if even one point is visible, the stmts in this clause are executed
    else:
        
        #loop this for all the visible IR points
        for i in range(0,countVisible):
            
            #if the ith point is visible (<>none) and there are upto two points visible (since we have only two dots)
            if (rptIR[i] <> None) and (countVisible <= 2):
                
                #calculate the displacement of the ith point from an earlier reference point. This relative displacement
                #is stored as a wiipoint object in a variable called point
                point.calculateDisplacement(frmRef.oldCoords[i],rptIR[i])
                #scale that displacement by the multiplier - this can be configured to span larger displays
                point.scaleBy(multiplier)
                
                #the following if clause is very important. If the size value is zero, it indicates that the ith dot
				#is at rest. Now in that case, you want the dot to move smoothly from rest, instead of jumping across 
				#the screen to some arbitrary location. So in the case that dot was at rest, we skip moving the dot
				#in this iteration of this function.
                
                if frmRef.oldCoords[i].size <> 0:			#non zero size value indicates that the dot was already moving
                    
                        frmRef.emit(SIGNAL("moveDot"),i,point.x,point.y)	#inform the GUI that the dot needs to be moved
                    
                
                #this line is also quite important and it saves the current IR coords as the reference point for the next call of this routine
                frmRef.oldCoords[i] = rptIR[i]
#----------------------------------------------------------------------------
#                              MAIN ROUTINE
#----------------------------------------------------------------------------
if __name__ == '__main__':
    
    app = QApplication(sys.argv)
    frm = IRTracking(handleReportDualPointTracking)
    frm.show()
    app.exec_()
