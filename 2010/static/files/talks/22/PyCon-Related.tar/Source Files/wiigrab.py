#-----------------------------------------------------------------------------
#   module name :   wiigrab.py
#   author      :   Asim Mittal (c) 2010
#   description :   This module defines the WiimoteEventGrabber Class and various
#                   other routines that are needed to work with the wiimote data

#   platform    :   Ubuntu 9.10 or higher (extra packages needed: pyqt4, pybluez)
#   
#   Disclamer
#   This file has been coded as part of a talk titled "Wii + Python = Intuitive Control"
#   delivered at the Python Conference (a.k.a PyCon), India 2010. The work here
#   purely for demonstartive and didactical purposes only and is meant to serve
#   as a guide to developing applications using the Nintendo Wii on Ubuntu using Python
#   The source code and associated documentation can be downloaded from my blog's
#   project page. The url for my blog is: http://baniyakiduniya.blogspot.com
#-----------------------------------------------------------------------------

import cwiid,time,wiipoint
from threading import Thread

class WiimoteEventGrabber (cwiid.Wiimote,Thread):
    """
    Wrapper for cwiid.Wiimote class. The object of this class upon creation
    searches for the nearest available wii remote and tries to connect to it
    If none is discovered, then an exception is raised by the class constructor
    
    """
    def __init__(self,handler,interval=0.001,objTemp=None):
        """
        handler =   callback routine which will be invoked and to which every report
                    from the wiimote will be directed. callback routine must be of the type:
                    callbackName(dictionaryRemoteState,referenceToRemoteObj)
                    
        dictionaryRemoteState looks like this:
        {'acc': (125, 125, 150), 'led': 1, 'ir_src': [None, None, None, None], 'rpt_mode': 14, 'ext_type': 0, 'buttons': 0, 'ru mble': 0, 'error': 0, 'battery': 85}
                        
        interval=   sampling interval between reports in seconds. default value is set
                    to 100 milliseconds (which allows for 10 reports in a second)
                    
        obj =       some temporary object that you would like to send to the callback routine
                    In the case of a GUI, you can send the form object as a reference to
                    the callback routine using this argument and control various parts of your 
                    UI using this reference
        """
        self.eventRaised = handler
        self.sleeptime   = interval
        self.stopThread  = False
        self.isDead      = False
        self.objtemp      = objTemp
        
        cwiid.Wiimote.__init__(self)
        Thread.__init__(self)
    #------------------------------------------------------------------------------
    def stop(self):
        """ this routine will stop the background thread and no more reports will be generated """
        self.stopThread = True
    #------------------------------------------------------------------------------
    def run(self):
        """ this routine will start the background thread and read data from the wii remote.
            Subsequently that data will be forwarded to the callback specified through the 
            handler argument of the constructor """

        self.stopThread = False
        while not self.stopThread:
            self.eventRaised(self.state,self,self.objtemp)
            time.sleep(self.sleeptime)

        self.isDead = True
    #------------------------------------------------------------------------------
    def join(self):
        """ closes the wii remote's data report and disconnects it """
        self.stop()
	self.led = 0
        self.rumble = 0
        while not self.isDead:pass
            
        
        self.close()
    #------------------------------------------------------------------------------
    def isAlive(self):	
        """ returns true if the background thread is still running, false if it has been stopped """
        return (not self.isDead)
    #------------------------------------------------------------------------------
    def setReportType(self,rptButton=True,rptAccel=True,rptIR=True):
        """ set the report properties from the wiimote.
            rptButton = if true, the button info will be reported
            rptAccel  = if true, the accelerometer info will be reported
            rptIR     = if true, the IR tracking info will be reported
        """
        report = 0
        if rptButton    :  report = report | cwiid.RPT_BTN  
        if rptAccel     :  report = report | cwiid.RPT_ACC
        if rptIR        :  report = report | cwiid.RPT_IR
        
        #assign the final report value to the report mode of the wiimote
        self.rpt_mode = report
    #------------------------------------------------------------------------------
    
    
        
#------------------------------------------------------------------------------
def getVisibleIRPoints(report):
    
    """
    This routine accepts the report (dictionary) and returns a tuple (list,int)
    the list in the tuple is of size four and contains the coordinates of the
    visible IR points.
    
    The int value in the tuple contains the number of points that are visible.
    
    for instance, if two points are visible, then the value returned is:
        ([pointCoords1, pointCoords2, None, None],2)
    """
    
    reportIR = report['ir_src']
    toReturn = [None,None,None,None]
    count = 0
    
    for i in range(0,len(reportIR)):
        eachEntry = reportIR[i]
        
        if eachEntry <> None: 
            point = wiipoint.IRPoint()
            point.getPointFromReportEntry(eachEntry)
            toReturn[i] = (point)
            count += 1
        
        else: break
        
            
    return toReturn,count
#------------------------------------------------------------------------------
def getNameOfButton(buttonValue):
	
    """ returns the name of the button whose integer code is passed as argumnet """
    dctBtnNames = {
    cwiid.BTN_1:"1",
    cwiid.BTN_2:"2",
    cwiid.BTN_A:"A",
    cwiid.BTN_B:"B",
    cwiid.BTN_DOWN:"Down",
    cwiid.BTN_HOME:"Home",
    cwiid.BTN_LEFT:"Left",
    cwiid.BTN_MINUS:"Minus",
    cwiid.BTN_PLUS:"Plus",
    cwiid.BTN_RIGHT:"Right",
    cwiid.BTN_UP:"Up",
	0: "None"
    }
    
    if dctBtnNames.has_key(buttonValue):
        return dctBtnNames[buttonValue]
    else:
        return "unrecognized"
#------------------------------------------------------------------------------
def resolveButtons(buttonValue):
    """ this routine resolves a button value into all the buttons that might have been pressed
        to generate this combination. For instance, BTN_A = 8, and BTN_B = 4. Now when A and B
        are pressed together, the buttonValue reported by the wiimote is the sum of all buttons 
        pressed i.e. 12
        
        When you pass "12" to this routine it returns [8,4]. This is true for any number of simultaneous
        keypresses.
        
        if a single button is pressed , for instance only BTN_A is pressed, then simply [8] is returned
        This routine helps resolve simultaneous button presses on the remote into its individual values
    """
    
    lstButtons = [cwiid.BTN_1,cwiid.BTN_2,cwiid.BTN_A,cwiid.BTN_B,cwiid.BTN_DOWN,cwiid.BTN_HOME,cwiid.BTN_LEFT,cwiid.BTN_MINUS,cwiid.BTN_PLUS,cwiid.BTN_RIGHT,cwiid.BTN_UP]
    lstButtons.sort()
    #obtain a list of all the buttons in ascending order
    
    #the following loop finds the first value in the sorted list that is greater than the argument
    #button value. So [1,2,4,8,16,128....4096] is the sorted list. If buttonValue = 12, then the loop
    #breaks at 16 (first value in the list that is greater than 12). so basically we will now
    #work only on the part of the list before 16 ie. [1,2,4,8] as no value greater that 12 would have been
    #pressed, or else the button value given by the wiimote would have been larger
    for i in range(0,len(lstButtons)):
        if lstButtons[i] > buttonValue:break
        elif lstButtons[i] == buttonValue: return [lstButtons[i]]
        
    
    #this list will contain the individually resolved key codes
    resolved = []
    
    #the following loop works only on the segment of the list grabbed by the previous loop. starting from
    #the greatest value to the lowest. So we work on [8,4,2,1]
    for i in range(i,-1,-1):
        
        #now if the sum of items (button codes) already present in the "resolved" list and the current
        #button code is lesser or equal to the button value, this key would have been definitely pressed
        #in order to generate the button code that was reported.
        
        #for instance 12 was generated, and we're now working on [8,4,2,1], so for the first pass of this
        #loop, check sum(all items in resolved list) + 8 < 12 or not. if so, then add 8
        #here is each pass for the example:
        # sum[0] + 8 <= 12 --> true, so, resolved = [8]
        # sum[8] + 4 <= 12 --> true, so, resolved = [8,4]
        # sum[8,4] + 2 <= 12 --> false cuz 8+4+2 = 14, skip this value
        # sum[8,4] + 1 <= 12 --> false cuz 8+4+1 = 13, skip this value
        if (sum(resolved)+lstButtons[i]) <= buttonValue:  
            resolved.append(lstButtons[i])
            
    #return all the values stored in the resolved list. These codes represent the buttons that were
    #used to generate the given value of the argument
    return resolved
    
#------------------------------------------------------------------------------
