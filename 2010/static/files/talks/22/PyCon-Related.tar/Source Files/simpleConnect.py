#-----------------------------------------------------------------------------
#   module name :   simpleConnect.py
#   author      :   Asim Mittal (c) 2010
#   description :   Demonstrates the following features:
#                   a. establishing connectivity and creating a wiimote object
#                   b. handling wiimote sensor data
#                   c. interpreting the sensor data and doing something useful

#   platform    :   Ubuntu 9.10 or higher (extra packages needed: pyqt4, pybluez)
#   
#   Disclamer
#   This file has been coded as part of a talk titled "Wii + Python = Intuitive Control"
#   delivered at the Python Conference (a.k.a PyCon), India 2010. The work here
#   purely for demonstartive and didactical purposes only and is meant to serve
#   as a guide to developing applications using the Nintendo Wii on Ubuntu using Python
#   The source code and associated documentation can be downloaded from my blog's
#   project page. The url for my blog is: http://baniyakiduniya.blogspot.com
#-----------------------------------------------------------------------------


import wiigrab,sys,time


def someEventHandler(reportFromWii,wiiObjRef,someTempRef):
	"""
	This is the callback routine for the wii remote. it simply gets the value of the 
	LED currently present on the remote and toggles it
	"""
	print reportFromWii
	curLedVal = reportFromWii['led']
	wiiObjRef.led = not curLedVal
	

#------------------------------------ MAIN ------------------------------------------
if __name__ == "__main__":
	
	#------------------ Create Object, Connect and Configure -------------------
	try:
		print "Press the buttons 1 & 2 together..."
		wiiObj = wiigrab.WiimoteEventGrabber(someEventHandler,1)
		wiiObj.setReportType()
		wiiObj.led = 15
	except:
		print "Wii remote not found. Please check that the device is discoverable"
		sys.exit(0)

	#---- Start the Wiimote as a thread with reports fed to assigned callback----
	wiiObj.start()
	
	#----------------- Run the Main loop so that the app doesn't die ------------
	try:
		print 'Start of App'
		while True: time.sleep(1)
	except:
		#very important call to join here, waits till the wiimote connection is closed and the 
		#wiimote is restored to its initial state
		wiiObj.join()
		print 'End of App'
	
