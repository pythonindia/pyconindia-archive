import sys,math,wiigrab,wiipoint,random
from PyQt4.QtGui import *
from PyQt4.QtCore import *


class Bounce(QWidget):
    
    def initWiimote(self):
        """ initialize the wii remote here """
        try:
            print 'Press buttons 1 & 2 together...'
            self.oldCoordsIR = [wiipoint.IRPoint(),wiipoint.IRPoint()]                  #this member tracks the reference coords of the IR points
            self.wiimote = wiigrab.WiimoteEventGrabber(self.handleWiimoteReport,0.05,self)   #create the wiimote object and set the callback
            self.wiimote.setReportType()                                                     #set the report type to default (send all reports)
            self.wiimote.led = 15                                                            #let all the wiimote LEDs be on
            self.wiimote.start()                                                             #start the wiimote object thread
            
        except:
            #the wiimote could not be found, or that port is blocked/closed
            QMessageBox.critical(self,'Connectivity Error','The application could not find any Wiimotes. Please ensure your device is discoverable and restart the application')
            #self.close()
            #sys.exit(0)
    #---------------------------------------------------------------------------        
    def closeEvent(self,event):
        print 'Waiting for Wiimote to disconnect'
        try:
            self.wiimote.join()
            'Wiimote disconnected successfully!!'
        except:
            print 'Wiimote object could not be located'
        print 'Closing App...'
    #---------------------------------------------------------------------------
    def initWindow(self,xOrigin,yOrigin,width,height):
        """ initialize the main window and create the painter object """
        self.setGeometry(xOrigin,yOrigin,xOrigin+width,yOrigin+height)          #set the window geometry
        self.setWindowTitle('Bounce')                                           #set the window title
        self.setAttribute(Qt.WA_PaintOutsidePaintEvent,True)                    #this attribute is very impt. allows us to paint without using paintEvent
        self.paint = QPainter()                                                 #create the painter object
    #---------------------------------------------------------------------------
    def initGameObjects(self):
        """ initialize the various parameters needed for the gameplay """
        self.sizeDot = 10                                                       #the size of the red/blue dots
        self.sizeBox = 30                                                       #size of the object box
        self.posRed = [10,self.height()- 40]                                      #this is the starting position of the red dot
        self.posBlue= [self.width()-20, self.height()-40]                        #this is the starting position of the blue dot
        self.posBox = [50,30]                                                   #this is the starting position of the object box
        
        speed = 5                                                               #the speed at which the object box moves (in pixels)
        self.boxSpeedX = speed                                                  #set uniform speed along both x and y directions
        self.boxSpeedY = speed
        self.boxColor = Qt.darkMagenta                                          #set the color of the object box
    #---------------------------------------------------------------------------        
    def __init__(self,xOrigin,yOrigin,width,height,parent=None):
        
        QWidget.__init__(self,parent)
        
        self.initWiimote()
        self.initWindow(xOrigin,yOrigin,width,height)
        self.initGameObjects()
    
        #this is the application timer, that is called every 40 milliseconds. The game engine runs through this timer
        self.timer = QTimer()
        
        #a few event bindings
        self.connect(self.timer,SIGNAL("timeout()"),self.timeOut)
        self.connect(self,SIGNAL("draw"),self.draw)         #this redraws the red/blue squares and the line between them
        self.connect(self,SIGNAL("moveRed"),self.moveRed)   #this repositions the coords of the red dot
        self.connect(self,SIGNAL("moveBlue"),self.moveBlue) #this repositions the coords of the blue dot
        
        #start the game
        self.timer.start(40)
    #---------------------------------------------------------------------------
    def timeOut(self):
        """ time out routine for the application's timer. Also the core logic of the gameplay
            this is where the animation and collision detection occurs
        """
        
        self.eraseBox(self.posBox[0],self.posBox[1])        #start by erasing the object box off the screen
        offset = 20                                         #this offset is used to create an invisible boundary near the edges of the window
        
        #get the slope and intercept for the line joining the two dots (red and blue). This info is used to create the equation
        #of this line and determine whether the box has collided with it
        slope,intercept = self.getSlopeAndIntercept(self.posBlue[0],self.posBlue[1],self.posRed[0],self.posRed[1])
        
        #the following construct is used to determine which dot is at a greater distance from the origin (top left)
        xMax = max(self.posBlue[0],self.posRed[0])      #xMax will store the xCoords of the dot which is further away
        xMin = min(self.posBlue[0],self.posRed[0])      #xMin will store the xCoords of the dot which is closer to the origin
        yMax = max(self.posBlue[1],self.posRed[1])      #yMax will store the yCoords of the dot which is further away
        yMin = min(self.posBlue[1],self.posRed[1])      #yMin will store the yCoords of the dot which is closer to the origin
        
        #the slope and intercept can help us find out what is the equation of the line, but the actual line (visible) on the screen
        #is only those set of values that lie between the red and blue dots. so the quickest way to get all the points that lie on
        #the line (and in between the red/blue dots) is simply look in between the max and min values we've just gotten
        #xMax,yMax --> represent the dot that is closer to the origin, and xMin,yMin represent the dot that is nearer
        
        xValidRange = range(xMin,xMax)                  # this is all the x values that lie on the line (in between the dots)
        yValidRange = range(yMin,yMax)                  # this is all the y values that lie on the line (in between the dots)
        
        #Now the box is intended to bounce of the edges of the window, the following clauses check for exactly that. The offset
        #value allows us to pad the window boundaries with a little space creating an invisible barrier off of which the box shall
        #bounce. So now the box will not touch the window edge exactly, but will bounce off slightly before it
        
        if (self.posBox[0] >= (self.width() - offset)) or (self.posBox[0] <= (offset)): self.boxSpeedX *= -1    # right edge and left edge respectively
        if (self.posBox[1] >= (self.height()- offset)) or (self.posBox[1] <= (offset)): self.boxSpeedY *= -1    # bottom and top edges respectively
        
        #following loop checks for collisions of the box with the line drawn between the red/blue dots
        
        collision = False                       #collision detected flag
        
        #we basically scan all the points in the object box and check if any of the points lie on the line
        #if they do, we have a collision. The box lies between (posBox[0],posBox[1]) and (posBox[0]+size,posBox[1]+size)
        
        for x in range(self.posBox[0],self.posBox[0]+self.sizeBox):                 #scan through all the x coords for the box
            
            for y in range(self.posBox[1],self.posBox[1]+self.sizeBox):             #scan through all the y coords for the box
                    
                #using the equation "y = mx + c" where m --> slope and c --> intercept, we can verify whether the point 
                #represented by (x,y) actually lies on the line or not. so we basically use 'x' to calculate y and check
                #if that calculated value is the same as the y value given by (x,y)
                
                calcY = int((slope*x) + intercept)
                
                if (y == calcY):
                    #on the line... but is it really in the part of the line between the red and blue squares
                    #this is where our valid range of X coords come in handy. if the current point (x,y) lies on
                    #the part of the line between red and blue dots the x coord must be in the range of values
                    #calculated earlier on
                    
                    if x in xValidRange:
                        #x,y is in fact the point of contact between the line and the box
                        xPtContact = x; yPtContact = y
                        xCenterBox,yCenterBox = self.getCenterOfBox()
                        collision = True
                        
                        #now that we've detected a collision, its time to create the bouncing effect, by changing
                        #the direction of motion. For this game, i'm only interested in changing the motion when
                        #the line is horizontal and is either above/below the box. So if the box was coming towards
                        #the line from the top (line is at bottom) and was moving towards the right, then I'd want
                        #it to continue moving rightward only in the opposite direction vertically ie. it was coming 
                        #from the top, touched the line, and starts going back towards the top --> so the speed in the
                        #Y direction is simply inverted
                        
                        if (yCenterBox < yPtContact) or (yCenterBox > yPtContact): self.boxSpeedY *= -1
                        self.toggleBoxColor()   #also, make the box change color for every collision
                        #we're done here, break out of innermost loop
                        break
                    
            #did a collision occur?? if so, then break out of this loop
            if collision == True: break 
        
        #after all that math, we now know exactly which direction the box would be moving in, this info
        #is given by the sign (+ or -) of the speed in x or y directions. Simply recompute the new position
        #of the box based on this speed (speed is nothing but how much the box is moved in X or Y in pixels)
        
        self.posBox[0] += self.boxSpeedX
        self.posBox[1] += self.boxSpeedY
        
        #the new position is stored in the variables, now repaint the window
        self.draw()
    #---------------------------------------------------------------------------
    def toggleBoxColor(self):
        """ this randomly changes the color of the box... like a power up or something !"""
        
        colorRange = [Qt.black,Qt.green,Qt.darkBlue,Qt.darkMagenta,Qt.cyan,Qt.magenta]  #all the colors that we like
        colorRange.remove(self.boxColor)                                                #remove the current color of the box from the selection process
        colorIndex = random.randint(0,len(colorRange)-1)                                #randomly choose some other color
        self.boxColor = colorRange[colorIndex]                                          #set the color to the box
    #---------------------------------------------------------------------------
    def paintEvent(self,event):
        """ the paintEvent is called at the beginning and paints only the two dots on the form """
        self.draw()
    #---------------------------------------------------------------------------
    def moveRed(self,delX,delY):
        """ alter the position of the red square """
        self.posRed[0] -= delX
        self.posRed[1] -= delY
    #---------------------------------------------------------------------------
    def moveBlue(self,delX,delY):
        """ alter the position of the blue square """
        self.posBlue[0] -= delX
        self.posBlue[1] -= delY
    #---------------------------------------------------------------------------
    def eraseDrawing(self):
        """ Erase the drawing. The form is repainted and the graphics are wiped clean. 
            This is important as it creates the illusion of "animation" or "movement"
        """
        self.paint.begin(self)
        self.paint.eraseRect(0,0,self.width(),self.height())
        self.paint.end()
    #---------------------------------------------------------------------------
    def drawBox(self,x,y):
        self.paint.begin(self)
        self.paint.setBrush(self.boxColor)
        self.paint.drawRect(x,y,self.sizeBox,self.sizeBox)
        self.paint.end()
    #---------------------------------------------------------------------------
    def eraseBox(self,x,y):
        offset = 1
        self.paint.begin(self)
        self.paint.eraseRect(x,y,self.sizeBox+offset,self.sizeBox+offset)
        self.paint.end()
    #---------------------------------------------------------------------------
    def drawRedDot(self,x,y):
        """ draws the red dot at the specified x,y coords """
        self.paint.begin(self)
        self.paint.setBrush(Qt.red)
        self.paint.drawRect(x,y,self.sizeDot,self.sizeDot)
        self.paint.end()
    #---------------------------------------------------------------------------
    def drawBlueDot(self,x,y):
        """ draws the blue dot at the specified x,y coords """
        self.paint.begin(self)
        self.paint.setBrush(Qt.blue)
        self.paint.drawRect(x,y,self.sizeDot,self.sizeDot)
        self.paint.end()
    #---------------------------------------------------------------------------
    def drawLine(self,x1,y1,x2,y2):
        """ draws the dotted line connecting the two colored dots """
        self.paint.begin(self)
        pen = QPen(Qt.black,2, Qt.DotLine)
        self.paint.setPen(pen)
        self.paint.drawLine(x1,y1,x2,y2)
        self.paint.end()
    #---------------------------------------------------------------------------
    def getLength(self,x1,y1,x2,y2):
        """ returns the magnitude of the line joining the dots """
        return math.sqrt(math.pow(x2-x1,2)+math.pow(y2-y1,2))
    #---------------------------------------------------------------------------
    def getSlopeAndIntercept(self,x1,y1,x2,y2):
        try:
            slope = float(y2-y1)/float(x2-x1)
        except:
            #divide by zero, denominator tends to infinity so, slope tends to 0
            slope = 0
        
        intercept = y1 - (slope*x1)    
        return slope,intercept
    #---------------------------------------------------------------------------
    def getCenterOfBox(self):
        x = self.posBox[0] + self.sizeBox/2
        y = self.posBox[1] + self.sizeBox/2
        return x,y
    #---------------------------------------------------------------------------
    def draw(self):
        """ draws the entire graphic --> the dots and the connecting line and the object box"""
        halfSize = self.sizeDot/2
        self.eraseDrawing()
        self.drawRedDot(self.posRed[0],self.posRed[1])
        self.drawBlueDot(self.posBlue[0],self.posBlue[1])
        self.drawLine(self.posRed[0]+halfSize,self.posRed[1]+halfSize,self.posBlue[0]+halfSize,self.posBlue[1]+halfSize)
        self.drawBox(self.posBox[0],self.posBox[1])
    #---------------------------------------------------------------------------
    def mouseMoveEvent(self,event):        
        """ this has been implemented to test the form using mouse click and drag event """
        cursorPos = event.pos()
        self.posBlue[0] = cursorPos.x()
        self.posBlue[1] = cursorPos.y()
        self.emit(SIGNAL("draw"))
    #---------------------------------------------------------------------------
    def keyPressEvent(self,event):
        """ this causes the positions of the dots to be shifted in the direction of the pressed arrow key """
        delX = 0; delY = 0
        increment =    10
        
        if      event.key() == Qt.Key_Right: delX+=increment
        elif    event.key() == Qt.Key_Left: delX-=increment
        elif    event.key() == Qt.Key_Up: delY-=increment
        elif    event.key() == Qt.Key_Down: delY +=increment
        
        #the moveRed and moveBlue signals, cause displacement w.r.t wiimote coords
        #which are opposite to the Qt coord system, therefore the negative sign
        self.emit(SIGNAL("moveRed"),-delX,-delY)
        self.emit(SIGNAL("moveBlue"),-delX,-delY)
    #---------------------------------------------------------------------------
    def handleWiimoteReport(self,report,wiiref,tmp):
        """ handles the events from the wii remote """
        
        rptIR,countVisible = wiigrab.getVisibleIRPoints(report)
        signals = [SIGNAL("moveBlue"),SIGNAL("moveRed")]
        scale = 2
        
        #if the maximum number of dots visible are 2, do the following
        if (countVisible > 0) and (countVisible < 3):
            
            #for each visible dot, perform the following operations
            for i in range(0,countVisible):
                
                #if the dot has some coordinate info
                if rptIR[i] <> None:
                    oldCoord = self.oldCoordsIR[i]              #save the old coordinate reference for this point
                    curCoord = rptIR[i]                         #save the current coordinate for this point
                
                    if oldCoord.size <> 0:                      #if this dot is not moving from rest position
                        delX = curCoord.x - oldCoord.x          #then compute displacement along the x and y directions
                        delY = curCoord.y - oldCoord.y          #displacement = current coords - old coords
                        
                        self.emit(signals[i],delX*scale,delY*scale) #tell the associated dot to move/displace by the same amount
                        #scaling is used so that a small movement of the IR point can effectively lead to a larger movement on screen
                
                    self.oldCoordsIR[i] = curCoord              #save the current coords as the reference for the next comparison
        
        elif countVisible == 0:
            #cannot see anymore IR points, rest the dots
            self.oldCoordsIR[0].size = 0
            self.oldCoordsIR[1].size = 0
            
            
#---------------------------------------------------------------------------
if __name__ == '__main__':
    
    app = QApplication(sys.argv)
    frm = Bounce(100,100,500,500)
    frm.show()
    app.exec_()
