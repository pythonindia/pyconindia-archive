from PyQt4.QtCore import *
from PyQt4.QtGui import *
from puzzleui import *

import sys,wiigrab,wiipoint

class PuzzleEkt(Ui_Form,QWidget):
    
    def initObjects(self):
        """ initialize the objects viz. the images, the cursors etc"""
        self.images = [self.img1, self.img2, self.img3, self.img4]
        self.initialPositions = [self.img1.pos(),self.img2.pos(),self.img3.pos(),self.img4.pos()]
        self.cursors = [self.cursor1,self.cursor2,None,None]
        self.selection = [None,None,None,None]
        
        self.timer = QTimer()
        self.paint = QPainter()
    #------------------------------------------------------------------------    
    def initWiimote(self,handler):
        """ setup the wiimote and assign the handler to process events """
        try:
            self.oldCoords = [wiipoint.IRPoint(),wiipoint.IRPoint()]
            print 'Press 1 & 2 together...'
            self.wiimote = wiigrab.WiimoteEventGrabber(handler)
            self.wiimote.setReportType()
            self.wiimote.led = 15
            self.wiimote.start()
        except:
            QMessageBox.critical(self,'Connectivity Error','The application could not find any Wiimotes. Please ensure your device is discoverable and restart the application')
            self.close()
            
    #------------------------------------------------------------------------
    def initWindow(self):
        """ configure the window """
        self.move(100,100)
    #------------------------------------------------------------------------    
    def __init__(self):
        """ class constructor """
        QWidget.__init__(self,None)
        self.setupUi(self)
        self.initWindow()
        self.initObjects()
        self.initWiimote(self.wiimoteReportHandler)
        self.setAttribute(Qt.WA_PaintOutsidePaintEvent,True)
        
        #event bindings go in here
        self.connect(self.timer,SIGNAL("timeout()"),self.timeout)
        self.connect(self,SIGNAL("moveDot"),self.moveDot)
        self.connect(self,SIGNAL("deselect"),self.dropSelected)
        
    #------------------------------------------------------------------------    
    def timeout(self):
        """ this is the tick handler for the application timer. Whenever the timer is running
            it checks if either of the cursors are positioned on top of any of the images.
            If they are, then it causes that particular image to be "selected"
        """
        for c in range(0,len(self.cursors)):        #loops through all the cursors in the workspace
            cursor = self.cursors[c]
            for image in self.images:               #loops through all the images in the workspace
                if self.isCursorOnImage(cursor,image) == True:  #if a cursor is found on an image
                    if self.selection[c] == None:               #and if that cursor hasn't selected anything yet
                        self.selection[c] = image               #mark that image to have been selected by that cursor
                        
        self.timer.stop()                           #stop the timer
                
    #------------------------------------------------------------------------
    def isCursorOnImage(self,cursor,image):
        """ this performs a check on the cursor and image object passed to it. If the cursor geometry
            is coincident with that of the specified image, then it returns true, else false
        """
        if cursor == None: return False
        
        xOriginImage = image.x()
        yOriginImage = image.y()
        widthImage = image.width()
        heightImage = image.height()
        
        xRange = range(xOriginImage,xOriginImage+widthImage)
        yRange = range(yOriginImage,yOriginImage+heightImage)
    
        xCursor = cursor.x()
        yCursor = cursor.y()
        
        if (xCursor in xRange) and (yCursor in yRange):
            return True
        else:
            return False
    #------------------------------------------------------------------------
    def moveDot(self,dot,delX,delY):
        """ displaces the cursor specified (by dot) by the specified distance along X and Y """
        
        #displace the cursor specified by 'dot' by delX and delY
        xNew = self.cursors[dot].x() - delX
        yNew = self.cursors[dot].y() - delY
        self.cursors[dot].move(xNew,yNew)
        
        #start the timer if it is not running already, and let it tick out at the end of 2 seconds
        #this is done to create the "Dwell click" effect. After two seconds are over, the timeout
        #routine will check if any of the cursors lie on any of the images, if yes, they will cause
        #the image to get selected under that cursor using the "selection" list
        if self.timer.isActive() == False: self.timer.start(2000)
        
        #get the current selection for the cursor and check if the selection bears an image
        selected = self.selection[dot]
        if selected <> None:
            #yes, this cursor does have an image selected by it, so displace the image by delX and delY too
            xNew = selected.x() - delX; yNew = selected.y() - delY
            selected.move(xNew,yNew)
            
    #------------------------------------------------------------------------
    def dropSelected(self,dot):
        """ this routine clears the image currently selected by the cursor specified by dot 
            this is quite important as this routine will cause the cursor to deselect the image
            and continue moving freely. After a dwell click occurs, the image and cursor move together
            to mimic a drag event. This routine allows the image to be "dropped" completing the drag and drop sequence
        """
        self.selection[dot] = None
        
    #------------------------------------------------------------------------
    def closeEvent(self,event):
        """ things to do before the app shuts down """
        print 'Closing'
        try:
            self.wiimote.join()
            print 'Wiimote disconnected successfully!'
        except:
            print 'Wiimote pipe was not closed properly'
            
    #------------------------------------------------------------------------
    def wiimoteReportHandler(self,report,wiiref,frmRef):
        """ handle the incoming reports from the wiimote. this routine is a lot similar to the 
            report handler for the dual point demo, except that in order to intiate a dwell click
            and then later deselect the image, it sends out the "move" signal when the IR point is 
            visible (so as long as the IR point for a particular cursor is visible, the move signal
            is generated) and sends out a "deselect" signal when the particular IR point for a cursor is
            not present (by sending the deselect signal for a particular cursor, the app understands when to
            drop the selected image and let the cursor move freely about the workspace)
        """
        rptIR,countVisible = wiigrab.getVisibleIRPoints(report)
        point = wiipoint.IRPoint()
        multiplier = 2
        
        #this if clause is executed when there are no points visible
        if countVisible == 0:
            for i in range(0,len(self.oldCoords)):
                self.oldCoords[i].nullify()
                self.emit(SIGNAL("deselect"),i)
        
        #if even one point is visible, the stmts in this clause are executed
        else:
            #loop this for all the visible IR points
            for i in range(0,countVisible):
                
                #if the ith point is visible (<>none) and there are upto two points visible (since we have only two dots)
                if (rptIR[i] <> None):
                    
                    point.calculateDisplacement(self.oldCoords[i],rptIR[i])
                    point.scaleBy(multiplier)
                    
                    if self.oldCoords[i].size <> 0:			
                       self.emit(SIGNAL("moveDot"),i,point.x,point.y)	
                    
                    self.oldCoords[i] = rptIR[i]
                
                #this is a peculiar case and occurs when the first IR point may disappear and the
                #second IR point is still on in view
                else:
                    self.emit(SIGNAL("deselect"),i);print 'deselecting'
        
#-----------------------------------------------------------------------------
if __name__ == '__main__':
    
    app = QApplication(sys.argv)
    frm = PuzzleEkt()
    frm.show()
    sys.exit(app.exec_())