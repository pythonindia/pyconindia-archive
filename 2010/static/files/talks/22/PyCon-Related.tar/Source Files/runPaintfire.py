#-----------------------------------------------------------------------------
#   module name :   runPaintFire.py
#   author      :   Asim Mittal (c) 2010
#   description :   Demonstrates the integration of xAutomation and IR Tracking
#   platform    :   Ubuntu 9.10 or higher (extra packages needed: pyqt4, pybluez)
#   
#   Disclamer
#   This file has been coded as part of a talk titled "Wii + Python = Intuitive Control"
#   delivered at the Python Conference (a.k.a PyCon), India 2010. The work here
#   purely for demonstartive and didactical purposes only and is meant to serve
#   as a guide to developing applications using the Nintendo Wii on Ubuntu using Python
#   The source code and associated documentation can be downloaded from my blog's
#   project page. The url for my blog is: http://baniyakiduniya.blogspot.com
#-----------------------------------------------------------------------------


from PyQt4.QtCore import *
from PyQt4.QtGui import *
import sys,wiipoint,os, math,wiigrab,time,pygame

#------------------------------------------------------------------------

buttonLeft  = 1
buttonRight = 2
isMouseDown = False

cmdStartFire = "xte \'keydown Control_L\' \'keydown Alt_L\' \'key f\' \'keyup Control_L\' \'keyup Alt_L\'"
cmdClearFire = "xte \'keydown Control_L\' \'keydown Alt_L\' \'key c\' \'keyup Alt_L\' \'keyup Control_L\'"
cmdStopFire  = "xte \'keyup Control_L\' \'keyup Alt_L\'"
cmdMouseMove = "xte \'mousemove %s %s\'"
isOnFire = False

#------------------------------------------------------------------------
def moveCursor(x,y):
    toSend = (cmdMouseMove%(int(x),int(y)))
    os.system(toSend)
#------------------------------------------------------------------------

def handleFirePainter(report,deviceRef,frmRef):
    
    global buttonLeft,buttonRight
    
    #find out the coords of the IR points which are visible
    rptIR,countVisible = wiigrab.getVisibleIRPoints(report)
    point = wiipoint.IRPoint()
    currentCursorCoords = wiipoint.IRPoint(0,0,5)
    multiplier = 1
            
    currentIRCoordsPt1 = rptIR[0]
    currentIRCoordsPt2 = rptIR[1]
    
    #if the first IR point is visible    
    if currentIRCoordsPt1 <> None:
        #start the fire
        os.system(cmdStartFire)
        moveCursor(1024-currentIRCoordsPt1.x,768-currentIRCoordsPt1.y)
        
    else:
        os.system(cmdStopFire)
        os.system(cmdClearFire)
            
    
       
        

#----------------------------------------------------------------------------
if __name__ == '__main__':
    try:
        wiiobject = wiigrab.WiimoteEventGrabber(handleFirePainter)
        wiiobject.setReportType()
        wiiobject.led = 15
        
    except:
        print 'Could not find any wii remotes. Please ensure that the wiimote is discoverable and try again'
        sys.exit(0)
    
    wiiobject.start()
    try:
        print 'Application started'
        while True: time.sleep(1)
    except:
        wiiobject.join()
        print 'End of application'
    
    
    