/**
 * Embed Jython in Java
 * 
 * Person - Interface to be used by Jython 
 */

public interface PersonInterface
{
    public String getName();
    public int getAge();
}

