
# This will be called by program that will embed Python 
# result will be shown on stdout
def multiply():
    c = 12345*6789
    print 'The result of 12345 x 6789 :', c
    return c

