javac -d . *.java
