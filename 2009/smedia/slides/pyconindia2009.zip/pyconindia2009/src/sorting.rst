=======================
To Sort or Not to Sort.
=======================

Computers spend more amount of time sorting than anything else.
===============================================================

It makes sense to know the sorting algorithm when doing algorithm intensive work or participating in any coding contest.
========================================================================================================================

It fun! Almost magical, that same thing done in *slightly* different way produce so many different results.
===========================================================================================================

