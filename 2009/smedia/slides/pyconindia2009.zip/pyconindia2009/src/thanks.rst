=======
Thanks!
=======

 - `O.R.Senthil Kumaran`_
 - `Presentation Slides and Source Files`_


.. _O.R.Senthil Kumaran: orsenthil@gmail.com
.. _Presentation Slides and Source Files: http://uthcode.googlecode.com/files/pyconindia2009.zip
