=======================
Path Finding Algorithms
=======================

Good examples for Recursion
===========================

.. literalinclude:: py31/findpath.py

.. literalinclude:: py31/findshortest.py


Source: Guido's essay.
