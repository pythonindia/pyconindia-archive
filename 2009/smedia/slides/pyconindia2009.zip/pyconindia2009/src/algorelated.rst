============================
Algorithms Related Resources
============================


 - `itertools module in Python Standard Library`_
 - `Easy AI with Python by Raymond Hettinger`_
 - `David Eppstein's Python Algorithms and Data Structures`_


.. _Easy AI with Python by Raymond Hettinger: http://us.pycon.org/2009/conference/schedule/event/71/
.. _itertools module in Python Standard Library: http://docs.python.org/3.1/library/itertools.html
.. _David Eppstein's Python Algorithms and Data Structures: http://www.ics.uci.edu/~eppstein/PADS/
