.. PyCon India 2009 - Algorithms in Python documentation master file, created by
   sphinx-quickstart on Wed Sep 23 10:28:44 2009.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Algorithms in Python
====================

.. toctree::

   suitable
   analysis
   prime
   sorting
   bogosort
   insertion
   selection
   shell
   quick
   merge
   bubble
   bisection
   runtimeanalysis
   timsort
   graph
   pathfinding
   resources
   algorelated
   thanks
