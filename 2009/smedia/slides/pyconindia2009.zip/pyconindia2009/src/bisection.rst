=============
bisect module
=============

Inserting elements into a list in a sorted order.
=================================================

This can be much more efficient than repeatedly sorting a list
==============================================================

Or Explicitly sorting a large list after it is constructed.
===========================================================

.. literalinclude:: py31/bisectionsort.py

