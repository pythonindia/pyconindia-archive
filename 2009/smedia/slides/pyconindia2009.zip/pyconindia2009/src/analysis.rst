==================
Algorithm Analysis
==================

Asymptote 
=========
  
     A line which approaches nearer to some curve than assignable
     distance, but, though infinitely extended, would never meet
     it. Asymptotes may be straight lines or curves. A rectilinear
     asymptote may be conceived as a tangent to the curve at an
     infinite distance.
     [1913 Webster]
