======================
Python's Internal Sort
======================

timsort
=======

Exploits the patterns in data, Wickedly fast on partially or already sorted list.
=================================================================================

non-recursive adaptive stable natural mergesort / binary insertion sort hybrid
==============================================================================

In a nutshell, the main routine marches over the array once, left to right, alternately identifying the next run, then merging it into the previous runs "intelligently".
=========================================================================================================================================================================

Java's sort modified to use timsort.
====================================
