===========================
What makes Python suitable?
===========================

Study of Algorithms is one of fundamental requirements in CS Education.
=======================================================================

Knowing about Algorithms is going to help Programmers.
======================================================

Unfortunately, in using traditional languages like C,C++ a lot of time is spent in understanding the syntax, semantics and program design that the idea of algorithm is overshadowed. 
=====================================================================================================================================================================================

Well, it can be argued that once a person becomes familiar with language syntax then algorithms using that language is easy.  *True*.
=====================================================================================================================================

But algorithm learning is language agnostic, that is why _they_ do it in pseudo code.
=====================================================================================

But you see, Python is so close to pseudo-code, so close to english and so so natural for anything... well, most natural for learning algorithms.
=================================================================================================================================================

Because it is easy to learn, easy to use and very easy to test your implementation and enhance your understanding.
==================================================================================================================
