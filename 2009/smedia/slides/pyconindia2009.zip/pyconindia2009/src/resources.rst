=========
Resources
=========

- `Sieve of Eratosthenes at ActiveState`_
- `Algorithm Education in Python - UC, Irvine`_
- `Guido's Graph Essay`_
- `Sorting in Python`_
- `Sorting Algorithm - Wikipedia`_


.. _Sieve of Eratosthenes at ActiveState: http://code.activestate.com/recipes/117119/
.. _Algorithm Education in Python - UC, Irvine: http://www.ece.uci.edu/~chou/py02/python.html
.. _Guido's Graph Essay: http://www.python.org/doc/essays/graphs.html
.. _Sorting in Python: http://wiki.python.org/moin/HowTo/Sorting
.. _Sorting Algorithm - Wikipedia: http://en.wikipedia.org/wiki/Sorting_algorithm
